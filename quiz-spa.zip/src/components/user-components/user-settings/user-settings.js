const UserSettings = () => {
    return (
      <div className="relative md:ml-64 pt-14">
        <div className="global-wrapper-div mx-auto w-full">
          test admin settings
        </div>
      </div>
    );
  };
  
  export default UserSettings;
  