export const ADMIN = 'admin';
export const USER = 'user';

//localStorage constants
export const USER_TYPE = 'userType'
export const TOKEN = 'token'