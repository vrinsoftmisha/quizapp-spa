export const API_ROUTES = {
  userLogin: "/auth/login",
};
